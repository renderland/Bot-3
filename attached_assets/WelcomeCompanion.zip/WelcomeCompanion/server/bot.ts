import { 
  Client, GatewayIntentBits, Events, Guild, GuildMember, 
  PartialGuildMember, TextChannel, Partials, Message, 
  Collection, ActivityType, ChannelType, BaseGuildTextChannel
} from 'discord.js';
import { storage } from './storage';
import { InsertServer, InsertChannel, InsertConfig } from '@shared/schema';

// Command interface
interface Command {
  name: string;
  description: string;
  permission?: string;
  execute: (message: Message, args: string[]) => Promise<void>;
}

// Discord bot client
export class DiscordBot {
  private client: Client;
  private token: string;
  private ready: boolean = false;
  private commands: Collection<string, Command> = new Collection();
  private prefix: string = '!';
  
  constructor() {
    this.token = process.env.DISCORD_BOT_TOKEN || '';
    
    if (!this.token) {
      console.error('DISCORD_BOT_TOKEN is not set. Bot will not start.');
    }
    
    // Register commands
    this.registerCommands();
    
    // Create Discord client with necessary intents
    // Note: GuildMembers is a privileged intent that requires enabling in the Discord Developer Portal
    // Make sure you enable "SERVER MEMBERS INTENT" in your bot settings at https://discord.com/developers/applications
    this.client = new Client({
      intents: [
        GatewayIntentBits.Guilds,           // For basic guild information
        GatewayIntentBits.GuildMembers,     // For member join/leave events (privileged)
        GatewayIntentBits.GuildMessages,    // For message events
        GatewayIntentBits.MessageContent,   // For accessing message content (privileged)
      ],
      partials: [Partials.GuildMember, Partials.User, Partials.Message, Partials.Channel]     // Enable handling partial objects
    });
    
    this.setupEventListeners();
  }
  
  // Register bot commands
  private registerCommands(): void {
    // Help command - shows available commands
    this.commands.set('help', {
      name: 'help',
      description: 'Kullanılabilir komutların listesini gösterir',
      async execute(message, args) {
        const commands = discordBot.getCommands();
        const commandList = Array.from(commands.values())
          .map(cmd => `\`${discordBot.getPrefix()}${cmd.name}\` - ${cmd.description}`)
          .join('\n');
        
        // Check if it's a text channel
        if (message.channel.type === ChannelType.GuildText) {  
          await message.channel.send({
            embeds: [{
              title: '📋 Komutlar',
              description: commandList,
              color: 0x3498db,
              footer: { text: 'Belirli bir komut hakkında daha fazla bilgi için !help <komut> yazın' }
            }]
          });
        } else {
          // Fallback if not in a text channel
          await message.reply('Bu komut sadece bir metin kanalında kullanılabilir.');
        }
      }
    });
    
    // Welcome test command - sends a test welcome message
    this.commands.set('welcome', {
      name: 'welcome',
      description: 'Hoş geldin mesajını test eder',
      permission: 'ADMINISTRATOR',
      async execute(message, args) {
        try {
          // Check if it's a text channel
          if (message.channel.type !== ChannelType.GuildText) {
            await message.reply('Bu komut sadece bir metin kanalında kullanılabilir.');
            return;
          }
          
          const config = await storage.getConfig(message.guild!.id);
          
          if (!config) {
            await message.channel.send('⚠️ Sunucu yapılandırması bulunamadı');
            return;
          }
          
          if (!config.welcomeEnabled) {
            await message.channel.send('⚠️ Hoş geldin mesajları devre dışı. Önce kontrol panelinden etkinleştirin.');
            return;
          }
          
          if (!config.welcomeChannelId) {
            await message.channel.send('⚠️ Hoş geldin kanalı ayarlanmamış. Önce kontrol panelinden ayarlayın.');
            return;
          }
          
          const welcomeMessage = config.welcomeMessage
            .replace('{user}', `<@${message.author.id}>`)
            .replace('{server}', message.guild!.name)
            .replace('{memberCount}', message.guild!.memberCount.toString());
            
          // Send a embed preview of the welcome message
          await message.channel.send({
            embeds: [{
              title: '📝 Hoş Geldin Mesajı Önizlemesi',
              description: welcomeMessage,
              color: 0x57F287, // Yeşil
              timestamp: new Date().toISOString()
            }]
          });
        } catch (error) {
          console.error('Error executing welcome test command:', error);
          if (message.channel.type === ChannelType.GuildText) {
            await message.channel.send('❌ Hoş geldin mesajını test ederken bir hata oluştu');
          } else {
            await message.reply('❌ Hoş geldin mesajını test ederken bir hata oluştu');
          }
        }
      }
    });
    
    // Leave test command - sends a test leave message
    this.commands.set('leave', {
      name: 'leave',
      description: 'Ayrılma mesajını test eder',
      permission: 'ADMINISTRATOR',
      async execute(message, args) {
        try {
          // Check if it's a text channel
          if (message.channel.type !== ChannelType.GuildText) {
            await message.reply('Bu komut sadece bir metin kanalında kullanılabilir.');
            return;
          }
          
          const config = await storage.getConfig(message.guild!.id);
          
          if (!config) {
            await message.channel.send('⚠️ Sunucu yapılandırması bulunamadı');
            return;
          }
          
          if (!config.leaveEnabled) {
            await message.channel.send('⚠️ Ayrılma mesajları devre dışı. Önce kontrol panelinden etkinleştirin.');
            return;
          }
          
          if (!config.leaveChannelId) {
            await message.channel.send('⚠️ Ayrılma kanalı ayarlanmamış. Önce kontrol panelinden ayarlayın.');
            return;
          }
          
          const leaveMessage = config.leaveMessage
            .replace('{user}', message.author.tag)
            .replace('{server}', message.guild!.name)
            .replace('{memberCount}', message.guild!.memberCount.toString());
            
          // Send a embed preview of the leave message
          await message.channel.send({
            embeds: [{
              title: '📝 Ayrılma Mesajı Önizlemesi',
              description: leaveMessage,
              color: 0xED4245, // Kırmızı
              timestamp: new Date().toISOString()
            }]
          });
        } catch (error) {
          console.error('Error executing leave test command:', error);
          if (message.channel.type === ChannelType.GuildText) {
            await message.channel.send('❌ Ayrılma mesajını test ederken bir hata oluştu');
          } else {
            await message.reply('❌ Ayrılma mesajını test ederken bir hata oluştu');
          }
        }
      }
    });
    
    // Status command - shows bot status
    this.commands.set('status', {
      name: 'status',
      description: 'Bot durumunu ve çalışma süresini gösterir',
      async execute(message, args) {
        // Check if it's a text channel
        if (message.channel.type === ChannelType.GuildText) {
          await message.channel.send({
            embeds: [{
              title: '🤖 Bot Durumu',
              fields: [
                {
                  name: 'Durum',
                  value: discordBot.isReady() ? '🟢 Çevrimiçi' : '🔴 Çevrimdışı',
                  inline: true
                },
                {
                  name: 'Çalışma Süresi',
                  value: discordBot.getUptime(),
                  inline: true
                },
                {
                  name: 'Sunucular',
                  value: discordBot.getServerCount().toString(),
                  inline: true
                }
              ],
              color: 0x57F287,
              timestamp: new Date().toISOString()
            }]
          });
        } else {
          await message.reply('Bu komut sadece bir metin kanalında kullanılabilir.');
        }
      }
    });
  }
  
  // Initialize the bot
  public async start(): Promise<void> {
    if (!this.token) {
      console.error('Cannot start bot without a token');
      return;
    }
    
    try {
      await this.client.login(this.token);
      console.log('Discord bot logged in successfully');
    } catch (error) {
      console.error('Failed to log in to Discord:', error);
    }
  }
  
  // Set up event listeners for Discord events
  private setupEventListeners(): void {
    // Bot ready event
    this.client.on(Events.ClientReady, async () => {
      this.ready = true;
      console.log(`Bot is ready! Logged in as ${this.client.user?.tag}`);
      
      // Set bot presence/status
      this.client.user?.setPresence({
        status: 'online',
        activities: [{
          name: `${this.prefix}help | ${this.client.guilds.cache.size} sunucu`,
          type: ActivityType.Watching
        }]
      });
      
      // Register all current servers
      this.client.guilds.cache.forEach(async (guild) => {
        await this.registerGuild(guild);
      });
    });
    
    // Guild join event
    this.client.on(Events.GuildCreate, async (guild) => {
      console.log(`Joined a new guild: ${guild.name}`);
      await this.registerGuild(guild);
      
      // Update presence with new server count
      this.client.user?.setPresence({
        status: 'online',
        activities: [{
          name: `${this.prefix}help | ${this.client.guilds.cache.size} sunucu`,
          type: ActivityType.Watching
        }]
      });
    });
    
    // Member join event
    this.client.on(Events.GuildMemberAdd, async (member) => {
      try {
        // Fetch full member data if this is a partial member
        if (member.partial) {
          await member.fetch();
        }
        await this.handleMemberJoin(member);
      } catch (error) {
        console.error('Error handling member join event:', error);
      }
    });
    
    // Member leave event
    this.client.on(Events.GuildMemberRemove, async (member) => {
      try {
        // Fetch full member data if this is a partial member
        if (member.partial) {
          await member.fetch();
        }
        await this.handleMemberLeave(member);
      } catch (error) {
        console.error('Error handling member leave event:', error);
      }
    });
    
    // Message event - handle commands
    this.client.on(Events.MessageCreate, async (message) => {
      // Ignore bot messages
      if (message.author.bot) return;
      
      // Check if message starts with prefix
      if (!message.content.startsWith(this.prefix)) return;
      
      // Parse command and arguments
      const args = message.content.slice(this.prefix.length).trim().split(/ +/);
      const commandName = args.shift()?.toLowerCase();
      
      if (!commandName) return;
      
      // Find the command
      const command = this.commands.get(commandName);
      if (!command) return;
      
      // Check permissions if needed
      if (command.permission && message.member) {
        const hasPermission = this.checkPermission(message, command.permission);
        if (!hasPermission) {
          await message.reply('⛔ Bu komutu kullanma izniniz yok.');
          return;
        }
      }
      
      // Execute the command
      try {
        await command.execute(message, args);
      } catch (error) {
        console.error(`Error executing command ${commandName}:`, error);
        await message.reply('❌ Bu komut çalıştırılırken bir hata oluştu.');
      }
    });
  }
  
  // Helper method to check permissions
  private checkPermission(message: Message, permission: string): boolean {
    if (permission === 'ADMINISTRATOR') {
      return message.member?.permissions.has('Administrator') || false;
    }
    return true;
  }
  
  // Getter methods for commands
  public getCommands(): Collection<string, Command> {
    return this.commands;
  }
  
  public getPrefix(): string {
    return this.prefix;
  }
  
  // Register a guild with our storage
  private async registerGuild(guild: Guild): Promise<void> {
    try {
      // Check if the server already exists
      const existingServer = await storage.getServer(guild.id);
      
      if (!existingServer) {
        // Create the server in our database
        const serverData: InsertServer = {
          id: guild.id,
          name: guild.name,
        };
        
        await storage.createServer(serverData);
        
        // Create default config for this server
        const configData: InsertConfig = {
          serverId: guild.id,
          welcomeEnabled: true,
          leaveEnabled: true,
          autoRoleEnabled: false,
          welcomeChannelId: guild.systemChannelId || undefined,
          leaveChannelId: guild.systemChannelId || undefined,
          welcomeMessage: "Hoş geldin {user}!",
          leaveMessage: "{user} aramızdan ayrıldı.",
          autoRoleId: undefined,
        };
        
        await storage.createConfig(configData);
        
        // Register channels
        guild.channels.cache.forEach(async (channel) => {
          if (channel.isTextBased()) {
            const channelData: InsertChannel = {
              id: channel.id,
              serverId: guild.id,
              name: channel.name,
            };
            
            await storage.createChannel(channelData);
          }
        });
      }
    } catch (error) {
      console.error(`Error registering guild ${guild.name}:`, error);
    }
  }
  
  // Handle member join event
  private async handleMemberJoin(member: GuildMember | PartialGuildMember): Promise<void> {
    try {
      const config = await storage.getConfig(member.guild.id);
      
      if (config && config.welcomeEnabled && config.welcomeChannelId) {
        const channel = member.guild.channels.cache.get(config.welcomeChannelId) as TextChannel;
        
        if (channel) {
          // Replace variables in welcome message
          const welcomeMessage = config.welcomeMessage
            .replace('{user}', `<@${member.id}>`)
            .replace('{server}', member.guild.name)
            .replace('{memberCount}', member.guild.memberCount.toString());
            
          // Send with green embed
          await channel.send({
            embeds: [{
              description: welcomeMessage,
              color: 0x57F287, // Yeşil
              timestamp: new Date().toISOString()
            }]
          });
        }
      }
      
      // Handle auto role assignment if enabled
      if (config && config.autoRoleEnabled && config.autoRoleId) {
        try {
          const role = member.guild.roles.cache.get(config.autoRoleId);
          if (role) {
            await member.roles.add(role);
          }
        } catch (error) {
          console.error(`Failed to assign role to ${member.user.tag}:`, error);
        }
      }
    } catch (error) {
      console.error(`Error handling member join for ${member.user.tag}:`, error);
    }
  }
  
  // Handle member leave event
  private async handleMemberLeave(member: GuildMember | PartialGuildMember): Promise<void> {
    try {
      const config = await storage.getConfig(member.guild.id);
      
      if (config && config.leaveEnabled && config.leaveChannelId) {
        const channel = member.guild.channels.cache.get(config.leaveChannelId) as TextChannel;
        
        if (channel) {
          // Replace variables in leave message
          const leaveMessage = config.leaveMessage
            .replace('{user}', member.user.tag)
            .replace('{server}', member.guild.name)
            .replace('{memberCount}', member.guild.memberCount.toString());
            
          // Send with red embed
          await channel.send({
            embeds: [{
              description: leaveMessage,
              color: 0xED4245, // Kırmızı
              timestamp: new Date().toISOString()
            }]
          });
        }
      }
    } catch (error) {
      console.error(`Error handling member leave for ${member.user.tag}:`, error);
    }
  }
  
  // Get bot status
  public isReady(): boolean {
    return this.ready;
  }
  
  // Get bot uptime
  public getUptime(): string {
    if (!this.client.uptime) return "Çevrimdışı";
    
    const totalSeconds = Math.floor(this.client.uptime / 1000);
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor(((totalSeconds % 86400) % 3600) / 60);
    
    const parts = [];
    if (days > 0) parts.push(`${days} gün`);
    if (hours > 0) parts.push(`${hours} saat`);
    if (minutes > 0) parts.push(`${minutes} dakika`);
    
    return parts.join(', ') || "Yeni başladı";
  }
  
  // Get the number of servers
  public getServerCount(): number {
    return this.client.guilds.cache.size;
  }
}

// Create singleton instance
export const discordBot = new DiscordBot();
