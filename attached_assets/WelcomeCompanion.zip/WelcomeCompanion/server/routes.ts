import express, { Router } from "express";
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { discordBot } from "./bot";
import { updateConfigSchema } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  const router = Router();

  // API routes
  router.get("/status", (req, res) => {
    res.json({
      status: discordBot.isReady() ? "online" : "offline",
      uptime: discordBot.getUptime(),
      serverCount: discordBot.getServerCount()
    });
  });

  // Get all servers
  router.get("/servers", async (req, res) => {
    try {
      const servers = await storage.getServers();
      res.json(servers);
    } catch (error) {
      console.error("Error fetching servers:", error);
      res.status(500).json({ error: "Failed to fetch servers" });
    }
  });

  // Get a specific server with its config
  router.get("/servers/:serverId", async (req, res) => {
    try {
      const { serverId } = req.params;
      const server = await storage.getServer(serverId);
      
      if (!server) {
        return res.status(404).json({ error: "Server not found" });
      }
      
      const config = await storage.getConfig(serverId);
      const channels = await storage.getChannels(serverId);
      
      res.json({
        server,
        config,
        channels
      });
    } catch (error) {
      console.error("Error fetching server details:", error);
      res.status(500).json({ error: "Failed to fetch server details" });
    }
  });

  // Update server configuration
  router.post("/servers/:serverId/config", async (req, res) => {
    try {
      const { serverId } = req.params;
      const server = await storage.getServer(serverId);
      
      if (!server) {
        return res.status(404).json({ error: "Server not found" });
      }
      
      // Validate input
      const validationResult = updateConfigSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        const validationError = fromZodError(validationResult.error);
        return res.status(400).json({ error: validationError.message });
      }
      
      // Update config
      const updatedConfig = await storage.updateConfig(serverId, validationResult.data);
      
      res.json(updatedConfig);
    } catch (error) {
      console.error("Error updating server config:", error);
      res.status(500).json({ error: "Failed to update server configuration" });
    }
  });

  // Get channels for a server
  router.get("/servers/:serverId/channels", async (req, res) => {
    try {
      const { serverId } = req.params;
      const server = await storage.getServer(serverId);
      
      if (!server) {
        return res.status(404).json({ error: "Server not found" });
      }
      
      const channels = await storage.getChannels(serverId);
      res.json(channels);
    } catch (error) {
      console.error("Error fetching channels:", error);
      res.status(500).json({ error: "Failed to fetch channels" });
    }
  });

  // Mount the router
  app.use("/api", router);

  // Initialize Discord bot
  discordBot.start().catch(err => {
    console.error("Failed to start Discord bot:", err);
  });

  const httpServer = createServer(app);

  return httpServer;
}
