import { 
  User, InsertUser, 
  Server, InsertServer, 
  Config, InsertConfig, UpdateConfig,
  Channel, InsertChannel
} from "@shared/schema";

// Interface for all storage operations
export interface IStorage {
  // User methods (existing)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Server methods
  getServer(id: string): Promise<Server | undefined>;
  getServers(): Promise<Server[]>;
  createServer(server: InsertServer): Promise<Server>;
  
  // Config methods
  getConfig(serverId: string): Promise<Config | undefined>;
  createConfig(config: InsertConfig): Promise<Config>;
  updateConfig(serverId: string, config: UpdateConfig): Promise<Config>;
  
  // Channel methods
  getChannels(serverId: string): Promise<Channel[]>;
  createChannel(channel: InsertChannel): Promise<Channel>;
  updateChannel(id: string, name: string): Promise<Channel>;
  deleteChannel(id: string): Promise<void>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private servers: Map<string, Server>;
  private configs: Map<string, Config>;
  private channels: Map<string, Channel>;
  private currentUserId: number;
  private currentConfigId: number;

  constructor() {
    this.users = new Map();
    this.servers = new Map();
    this.configs = new Map();
    this.channels = new Map();
    this.currentUserId = 1;
    this.currentConfigId = 1;
  }

  // User methods (existing)
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Server methods
  async getServer(id: string): Promise<Server | undefined> {
    return this.servers.get(id);
  }

  async getServers(): Promise<Server[]> {
    return Array.from(this.servers.values());
  }

  async createServer(server: InsertServer): Promise<Server> {
    const newServer: Server = { 
      ...server, 
      joinedAt: new Date() 
    };
    this.servers.set(server.id, newServer);
    return newServer;
  }

  // Config methods
  async getConfig(serverId: string): Promise<Config | undefined> {
    return Array.from(this.configs.values()).find(
      (config) => config.serverId === serverId
    );
  }

  async createConfig(config: InsertConfig): Promise<Config> {
    const id = this.currentConfigId++;
    // Ensure all required fields are present with default values if not provided
    const newConfig: Config = {
      id,
      serverId: config.serverId,
      welcomeEnabled: config.welcomeEnabled ?? true,
      leaveEnabled: config.leaveEnabled ?? true,
      autoRoleEnabled: config.autoRoleEnabled ?? false,
      welcomeChannelId: config.welcomeChannelId ?? null,
      leaveChannelId: config.leaveChannelId ?? null,
      welcomeMessage: config.welcomeMessage ?? "Welcome {user} to the server! We're glad to have you here!",
      leaveMessage: config.leaveMessage ?? "{user} has left the server. We hope to see you again!",
      autoRoleId: config.autoRoleId ?? null
    };
    this.configs.set(config.serverId, newConfig);
    return newConfig;
  }

  async updateConfig(serverId: string, updateConfig: UpdateConfig): Promise<Config> {
    const existingConfig = await this.getConfig(serverId);
    
    if (!existingConfig) {
      throw new Error(`Config for server ${serverId} not found`);
    }
    
    const updatedConfig: Config = {
      ...existingConfig,
      ...updateConfig
    };
    
    this.configs.set(serverId, updatedConfig);
    return updatedConfig;
  }

  // Channel methods
  async getChannels(serverId: string): Promise<Channel[]> {
    return Array.from(this.channels.values()).filter(
      (channel) => channel.serverId === serverId
    );
  }

  async createChannel(channel: InsertChannel): Promise<Channel> {
    this.channels.set(channel.id, channel);
    return channel;
  }

  async updateChannel(id: string, name: string): Promise<Channel> {
    const channel = this.channels.get(id);
    
    if (!channel) {
      throw new Error(`Channel ${id} not found`);
    }
    
    const updatedChannel: Channel = {
      ...channel,
      name
    };
    
    this.channels.set(id, updatedChannel);
    return updatedChannel;
  }

  async deleteChannel(id: string): Promise<void> {
    this.channels.delete(id);
  }
}

export const storage = new MemStorage();
