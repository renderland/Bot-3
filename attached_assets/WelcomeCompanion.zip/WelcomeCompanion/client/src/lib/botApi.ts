import { apiRequest } from './queryClient';

export interface BotStatus {
  status: 'online' | 'offline';
  uptime: string;
  serverCount: number;
}

export interface Channel {
  id: string;
  serverId: string;
  name: string;
}

export interface Server {
  id: string;
  name: string;
  joinedAt: string;
}

export interface Config {
  id: number;
  serverId: string;
  welcomeEnabled: boolean;
  leaveEnabled: boolean;
  autoRoleEnabled: boolean;
  welcomeChannelId?: string;
  leaveChannelId?: string;
  welcomeMessage: string;
  leaveMessage: string;
  autoRoleId?: string;
}

export interface ServerDetails {
  server: Server;
  config: Config;
  channels: Channel[];
}

export interface UpdateConfig {
  welcomeEnabled?: boolean;
  leaveEnabled?: boolean;
  autoRoleEnabled?: boolean;
  welcomeChannelId?: string;
  leaveChannelId?: string;
  welcomeMessage?: string;
  leaveMessage?: string;
  autoRoleId?: string;
}

// API functions
export async function fetchBotStatus(): Promise<BotStatus> {
  const response = await fetch('/api/status', { credentials: 'include' });
  if (!response.ok) {
    throw new Error('Failed to fetch bot status');
  }
  return response.json();
}

export async function fetchServers(): Promise<Server[]> {
  const response = await fetch('/api/servers', { credentials: 'include' });
  if (!response.ok) {
    throw new Error('Failed to fetch servers');
  }
  return response.json();
}

export async function fetchServerDetails(serverId: string): Promise<ServerDetails> {
  const response = await fetch(`/api/servers/${serverId}`, { credentials: 'include' });
  if (!response.ok) {
    throw new Error('Failed to fetch server details');
  }
  return response.json();
}

export async function updateServerConfig(serverId: string, config: UpdateConfig): Promise<Config> {
  const res = await apiRequest('POST', `/api/servers/${serverId}/config`, config);
  return res.json();
}

export async function fetchServerChannels(serverId: string): Promise<Channel[]> {
  const response = await fetch(`/api/servers/${serverId}/channels`, { credentials: 'include' });
  if (!response.ok) {
    throw new Error('Failed to fetch server channels');
  }
  return response.json();
}
