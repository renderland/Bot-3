import { Sidebar } from "../components/Sidebar";
import { CommandsTable } from "../components/CommandsTable";

export default function Commands() {
  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-[#36393F] text-[#DCDDDE]">
      <Sidebar />
      
      <div className="flex-1 overflow-auto">
        <header className="bg-[#36393F] p-4 border-b border-gray-700 flex justify-between items-center">
          <h1 className="text-xl font-semibold text-white">Yardım & Komutlar</h1>
        </header>
        
        <div className="p-6">
          <div className="bg-[#36393F] rounded-lg shadow-lg p-5 mb-6">
            <h2 className="text-lg font-semibold text-white mb-4">Bot Dokümantasyonu</h2>
            <div className="prose prose-invert max-w-none">
              <p>
                Discord Hoş Geldin Botu, sunucunuza katılan yeni üyeleri özelleştirilebilir karşılama mesajlarıyla selamlamak ve ayrılan üyeleri bildirmek için tasarlanmıştır.
              </p>
              
              <h3 className="text-white mt-6 mb-2">Özellikler</h3>
              <ul className="list-disc pl-6 space-y-2 text-[#B9BBBE]">
                <li>Kullanıcılar sunucunuza katıldığında özelleştirilebilir hoş geldin mesajları</li>
                <li>Kullanıcılar sunucunuzdan ayrıldığında özelleştirilebilir ayrılma mesajları</li>
                <li>Mesajları kişiselleştirmek için değişken desteği ({'{user}'}, {'{server}'}, {'{memberCount}'})</li>
                <li>Hoş geldin ve ayrılma mesajları için belirli kanalları seçme</li>
                <li>Yeni üyeler için isteğe bağlı otomatik rol atama</li>
                <li>Bot ayarlarını test etmek ve yönetmek için komut sistemi</li>
              </ul>
              
              <h3 className="text-white mt-6 mb-2">Kurulum</h3>
              <ol className="list-decimal pl-6 space-y-2 text-[#B9BBBE]">
                <li>Botu sunucunuza davet edin</li>
                <li>Sunucunuzun yapılandırma sayfasına gidin</li>
                <li>Kullanmak istediğiniz özellikleri etkinleştirin</li>
                <li>Hoş geldin ve ayrılma mesajlarınızı özelleştirin</li>
                <li>Mesajların gönderileceği kanalları seçin</li>
                <li>Yapılandırmanızı kaydedin</li>
              </ol>
              
              <h3 className="text-white mt-6 mb-2">Mesaj Değişkenleri</h3>
              <p>Mesajlarınızda bu değişkenleri kullanabilirsiniz:</p>
              <ul className="list-disc pl-6 space-y-2 text-[#B9BBBE]">
                <li><code>{'{user}'}</code> - Katılan/ayrılan kullanıcıyı etiketler</li>
                <li><code>{'{server}'}</code> - Sunucu adını gösterir</li>
                <li><code>{'{memberCount}'}</code> - Mevcut üye sayısını gösterir</li>
              </ul>
              
              <h3 className="text-white mt-6 mb-2">Bot Komutlarını Kullanma</h3>
              <p>Bot, herhangi bir metin kanalında <code>!</code> ile başlayan komutlara yanıt verir. Bu komutları özellikleri test etmek veya botun durumunu kontrol etmek için kullanabilirsiniz.</p>
              <p className="mt-2">Örneğin, <code>!help</code> yazmak kullanılabilir komutların bir listesini gösterecek ve <code>!welcome</code> hoş geldin mesajınızın bir önizlemesini mevcut kanalda gösterecektir (yalnızca yöneticiler).</p>
              <p className="mt-2 text-yellow-300">Not: Hoş geldin/ayrılma olaylarının çalışması için botun Discord Geliştirici Portalında "Server Members Intent" ayrıcalığının etkinleştirilmesi gerekir.</p>
            </div>
          </div>
          
          <CommandsTable />
        </div>
      </div>
    </div>
  );
}
