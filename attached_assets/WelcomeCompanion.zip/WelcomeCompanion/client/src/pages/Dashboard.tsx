import { StatusCard } from "../components/StatusCard";
import { Sidebar } from "../components/Sidebar";
import { CommandsTable } from "../components/CommandsTable";
import { useToast } from "@/hooks/use-toast";

export default function Dashboard() {
  const { toast } = useToast();

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-[#36393F] text-[#DCDDDE]">
      <Sidebar />
      
      <div className="flex-1 overflow-auto">
        <header className="bg-[#36393F] p-4 border-b border-gray-700 flex justify-between items-center">
          <h1 className="text-xl font-semibold text-white">Welcome Bot Dashboard</h1>
        </header>
        
        <div className="p-6">
          <StatusCard />
          
          <div className="bg-[#36393F] rounded-lg shadow-lg p-5 mb-6">
            <h2 className="text-lg font-semibold text-white mb-4">Getting Started</h2>
            <p className="mb-4 text-[#B9BBBE]">
              Welcome to your Discord Welcome Bot! Use this dashboard to configure welcome and leave messages for your Discord servers.
            </p>
            <div className="space-y-2">
              <div className="bg-[#2F3136] p-3 rounded border-l-4 border-[#5865F2]">
                <h3 className="font-medium text-white mb-1">Step 1: Invite the bot to your server</h3>
                <p className="text-sm text-[#B9BBBE]">
                  Click on one of your servers in the sidebar to start configuring it.
                </p>
              </div>
              <div className="bg-[#2F3136] p-3 rounded border-l-4 border-[#5865F2]">
                <h3 className="font-medium text-white mb-1">Step 2: Configure welcome and leave messages</h3>
                <p className="text-sm text-[#B9BBBE]">
                  Customize your messages and select the channels where they should be sent.
                </p>
              </div>
              <div className="bg-[#2F3136] p-3 rounded border-l-4 border-[#5865F2]">
                <h3 className="font-medium text-white mb-1">Step 3: Save your configuration</h3>
                <p className="text-sm text-[#B9BBBE]">
                  Don't forget to save your changes!
                </p>
              </div>
            </div>
          </div>
          
          <CommandsTable />
        </div>
      </div>
    </div>
  );
}
