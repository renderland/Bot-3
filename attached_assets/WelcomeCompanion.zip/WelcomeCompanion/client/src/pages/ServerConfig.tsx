import { useState, useEffect } from 'react';
import { useRoute, useLocation } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Sidebar } from '../components/Sidebar';
import { StatusCard } from '../components/StatusCard';
import { FeaturesConfig } from '../components/FeaturesConfig';
import { MessageConfig } from '../components/MessageConfig';
import { CommandsTable } from '../components/CommandsTable';
import { fetchServerDetails, updateServerConfig, UpdateConfig } from '../lib/botApi';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function ServerConfig() {
  const [_, params] = useRoute<{ serverId: string }>('/servers/:serverId');
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const serverId = params?.serverId || '';
  const [configChanges, setConfigChanges] = useState<UpdateConfig>({});
  const [hasChanges, setHasChanges] = useState(false);
  
  const { data: serverDetails, isLoading } = useQuery({
    queryKey: [`/api/servers/${serverId}`],
    queryFn: () => fetchServerDetails(serverId),
    enabled: !!serverId,
  });
  
  const mutation = useMutation({
    mutationFn: (config: UpdateConfig) => updateServerConfig(serverId, config),
    onSuccess: () => {
      toast({
        title: "Configuration saved",
        description: "Your bot settings have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/servers/${serverId}`] });
      setConfigChanges({});
      setHasChanges(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to save",
        description: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    },
  });
  
  useEffect(() => {
    setHasChanges(Object.keys(configChanges).length > 0);
  }, [configChanges]);
  
  const handleConfigChange = (updates: Partial<UpdateConfig>) => {
    setConfigChanges(prev => ({ ...prev, ...updates }));
  };
  
  const handleSaveChanges = () => {
    if (hasChanges) {
      mutation.mutate(configChanges);
    }
  };
  
  const handleReset = () => {
    setConfigChanges({});
    setHasChanges(false);
  };
  
  if (!serverId) {
    navigate('/');
    return null;
  }
  
  if (isLoading) {
    return (
      <div className="flex flex-col lg:flex-row min-h-screen bg-[#36393F] text-[#DCDDDE]">
        <Sidebar />
        <div className="flex-1 p-8 flex items-center justify-center">
          <div className="flex flex-col items-center">
            <Loader2 className="h-8 w-8 animate-spin text-[#5865F2]" />
            <p className="mt-4 text-lg">Loading server configuration...</p>
          </div>
        </div>
      </div>
    );
  }
  
  if (!serverDetails) {
    return (
      <div className="flex flex-col lg:flex-row min-h-screen bg-[#36393F] text-[#DCDDDE]">
        <Sidebar />
        <div className="flex-1 p-8">
          <div className="bg-[#36393F] rounded-lg shadow-lg p-5 mb-6">
            <h2 className="text-lg font-semibold text-white mb-4">Server Not Found</h2>
            <p className="text-[#B9BBBE]">
              The server you're looking for doesn't exist or the bot doesn't have access to it.
            </p>
            <Button 
              className="mt-4 bg-[#5865F2] hover:bg-opacity-80"
              onClick={() => navigate('/')}
            >
              Return to Dashboard
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  const mergedConfig = { ...serverDetails.config, ...configChanges };
  
  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-[#36393F] text-[#DCDDDE]">
      <Sidebar />
      
      <div className="flex-1 overflow-auto">
        <header className="bg-[#36393F] p-4 border-b border-gray-700 flex justify-between items-center">
          <h1 className="text-xl font-semibold text-white">
            {serverDetails.server.name} Configuration
          </h1>
          <div className="flex items-center space-x-3">
            <Button 
              className="bg-[#5865F2] hover:bg-opacity-80 text-white transition"
              onClick={handleSaveChanges}
              disabled={!hasChanges || mutation.isPending}
            >
              {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Changes
            </Button>
            <Button 
              className="bg-[#2F3136] hover:bg-gray-700 text-[#B9BBBE] transition"
              onClick={handleReset}
              disabled={!hasChanges || mutation.isPending}
            >
              Reset
            </Button>
          </div>
        </header>
        
        <div className="p-6">
          <StatusCard />
          
          <FeaturesConfig 
            config={mergedConfig} 
            onConfigChange={handleConfigChange}
            isUpdating={mutation.isPending}
          />
          
          <MessageConfig 
            config={mergedConfig} 
            channels={serverDetails.channels}
            onConfigChange={handleConfigChange}
            isUpdating={mutation.isPending}
          />
          
          <CommandsTable />
        </div>
      </div>
    </div>
  );
}
