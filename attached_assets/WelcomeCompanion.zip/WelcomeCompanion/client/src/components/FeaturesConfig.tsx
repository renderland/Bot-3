import { useState } from 'react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Config } from '../lib/botApi';

interface FeaturesConfigProps {
  config: Config;
  onConfigChange: (updates: Partial<Config>) => void;
  isUpdating: boolean;
}

export function FeaturesConfig({ config, onConfigChange, isUpdating }: FeaturesConfigProps) {
  return (
    <div className="bg-[#36393F] rounded-lg shadow-lg p-5 mb-6">
      <h2 className="text-lg font-semibold text-white mb-4">Features</h2>
      <div className="space-y-4">
        {/* Welcome Message Toggle */}
        <div className="flex items-center justify-between p-3 bg-[#2F3136] rounded-md">
          <div>
            <h3 className="font-medium text-white">Welcome Messages</h3>
            <p className="text-sm text-[#B9BBBE]">Send a message when users join</p>
          </div>
          <div className="flex items-center space-x-2">
            <Switch 
              id="welcomeToggle" 
              checked={config.welcomeEnabled}
              onCheckedChange={(checked) => onConfigChange({ welcomeEnabled: checked })}
              disabled={isUpdating}
              className={config.welcomeEnabled ? "bg-[#5865F2]" : ""}
            />
            <Label htmlFor="welcomeToggle" className="sr-only">
              Welcome Messages
            </Label>
          </div>
        </div>

        {/* Leave Message Toggle */}
        <div className="flex items-center justify-between p-3 bg-[#2F3136] rounded-md">
          <div>
            <h3 className="font-medium text-white">Leave Messages</h3>
            <p className="text-sm text-[#B9BBBE]">Send a message when users leave</p>
          </div>
          <div className="flex items-center space-x-2">
            <Switch 
              id="leaveToggle" 
              checked={config.leaveEnabled}
              onCheckedChange={(checked) => onConfigChange({ leaveEnabled: checked })}
              disabled={isUpdating}
              className={config.leaveEnabled ? "bg-[#5865F2]" : ""}
            />
            <Label htmlFor="leaveToggle" className="sr-only">
              Leave Messages
            </Label>
          </div>
        </div>

        {/* Role Assignment Toggle */}
        <div className="flex items-center justify-between p-3 bg-[#2F3136] rounded-md">
          <div>
            <h3 className="font-medium text-white">Auto Role Assignment</h3>
            <p className="text-sm text-[#B9BBBE]">Automatically assign roles to new members</p>
          </div>
          <div className="flex items-center space-x-2">
            <Switch 
              id="roleToggle" 
              checked={config.autoRoleEnabled}
              onCheckedChange={(checked) => onConfigChange({ autoRoleEnabled: checked })}
              disabled={isUpdating}
              className={config.autoRoleEnabled ? "bg-[#5865F2]" : ""}
            />
            <Label htmlFor="roleToggle" className="sr-only">
              Auto Role Assignment
            </Label>
          </div>
        </div>
      </div>
    </div>
  );
}
