import { Link, useLocation } from 'wouter';
import { Server } from '../lib/botApi';
import { useQuery } from '@tanstack/react-query';
import { fetchServers } from '../lib/botApi';
import { Zap, Settings, FileText, HelpCircle } from 'lucide-react';

export function Sidebar() {
  const [location] = useLocation();
  
  const { data: servers, isLoading } = useQuery({
    queryKey: ['/api/servers'],
    queryFn: fetchServers,
  });

  return (
    <div className="w-full lg:w-64 bg-[#2F3136] flex-shrink-0 flex flex-col h-screen">
      <div className="p-4 border-b border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-[#5865F2] flex items-center justify-center">
            <Zap className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-white font-semibold text-lg">Welcome Bot</h1>
            <div className="flex items-center">
              <span className="h-2 w-2 rounded-full bg-[#57F287] mr-2"></span>
              <span className="text-xs text-[#B9BBBE]">Online</span>
            </div>
          </div>
        </div>
      </div>

      <nav className="p-2">
        <ul>
          <li>
            <Link href="/">
              <div className={`flex items-center p-3 rounded-md ${location === '/' ? 'bg-[#5865F2] bg-opacity-20 text-white' : 'hover:bg-[#5865F2] hover:bg-opacity-10 text-[#B9BBBE]'} mb-1 cursor-pointer`}>
                <Settings className="h-5 w-5 mr-3" />
                Configuration
              </div>
            </Link>
          </li>
          <li>
            <Link href="/logs">
              <div className={`flex items-center p-3 rounded-md ${location === '/logs' ? 'bg-[#5865F2] bg-opacity-20 text-white' : 'hover:bg-[#5865F2] hover:bg-opacity-10 text-[#B9BBBE]'} mb-1 cursor-pointer`}>
                <FileText className="h-5 w-5 mr-3" />
                Logs
              </div>
            </Link>
          </li>
          <li>
            <Link href="/commands">
              <div className={`flex items-center p-3 rounded-md ${location === '/commands' ? 'bg-[#5865F2] bg-opacity-20 text-white' : 'hover:bg-[#5865F2] hover:bg-opacity-10 text-[#B9BBBE]'} mb-1 cursor-pointer`}>
                <HelpCircle className="h-5 w-5 mr-3" />
                Help
              </div>
            </Link>
          </li>
        </ul>

        <div className="mt-6 p-3">
          <h3 className="uppercase text-xs font-semibold text-[#B9BBBE] mb-2">Connected Servers</h3>
          <ul>
            {isLoading ? (
              <li className="text-[#B9BBBE] text-sm">Loading servers...</li>
            ) : servers && servers.length > 0 ? (
              servers.map((server) => (
                <li key={server.id}>
                  <Link href={`/servers/${server.id}`}>
                    <div className={`flex items-center p-2 rounded-md hover:bg-[#5865F2] hover:bg-opacity-10 mb-1 ${location === `/servers/${server.id}` ? 'bg-[#5865F2] bg-opacity-10' : ''} cursor-pointer`}>
                      <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center mr-3 overflow-hidden">
                        <span className="text-xs font-bold">{server.name.substring(0, 2).toUpperCase()}</span>
                      </div>
                      <span className="text-[#DCDDDE]">{server.name}</span>
                    </div>
                  </Link>
                </li>
              ))
            ) : (
              <li className="text-[#B9BBBE] text-sm">No servers connected</li>
            )}
          </ul>
        </div>
      </nav>

      <div className="mt-auto p-4 border-t border-gray-700">
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center mr-3">
            <span className="text-xs font-bold">B</span>
          </div>
          <div>
            <div className="text-sm font-medium text-white">Bot User</div>
            <div className="text-xs text-[#B9BBBE]">Online</div>
          </div>
        </div>
      </div>
    </div>
  );
}
