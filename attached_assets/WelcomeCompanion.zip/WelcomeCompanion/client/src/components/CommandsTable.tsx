import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface Command {
  name: string;
  description: string;
  permission: string;
}

const commandsList: Command[] = [
  {
    name: "!help",
    description: "Kullanılabilir komutların listesini gösterir",
    permission: "Herkes"
  },
  {
    name: "!welcome",
    description: "Hoş geldin mesajını test eder ve önizleme gösterir",
    permission: "Admin"
  },
  {
    name: "!leave",
    description: "Ayrılma mesajını test eder ve önizleme gösterir",
    permission: "Admin"
  },
  {
    name: "!status",
    description: "Bot durumunu, çalışma süresini ve sunucu sayısını gösterir",
    permission: "Herkes"
  }
];

export function CommandsTable() {
  return (
    <div className="bg-[#36393F] rounded-lg shadow-lg p-5 mb-6">
      <h2 className="text-lg font-semibold text-white mb-4">Kullanılabilir Komutlar</h2>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="bg-[#2F3136]">
            <TableRow>
              <TableHead className="text-[#B9BBBE] uppercase">Komut</TableHead>
              <TableHead className="text-[#B9BBBE] uppercase">Açıklama</TableHead>
              <TableHead className="text-[#B9BBBE] uppercase">İzin</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody className="bg-[#36393F] divide-y divide-gray-700">
            {commandsList.map((command) => (
              <TableRow key={command.name} className="border-b border-gray-700">
                <TableCell className="font-mono text-white">{command.name}</TableCell>
                <TableCell className="text-[#B9BBBE]">{command.description}</TableCell>
                <TableCell className="text-[#B9BBBE]">{command.permission}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
