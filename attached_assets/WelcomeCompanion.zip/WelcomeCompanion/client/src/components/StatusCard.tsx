import { useQuery } from '@tanstack/react-query';
import { fetchBotStatus } from '../lib/botApi';
import { Skeleton } from '@/components/ui/skeleton';

export function StatusCard() {
  const { data: status, isLoading } = useQuery({
    queryKey: ['/api/status'],
    queryFn: fetchBotStatus,
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (isLoading) {
    return (
      <div className="bg-[#36393F] rounded-lg shadow-lg p-5 mb-6">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-lg font-semibold text-white mb-2">Bot Status</h2>
            <p className="text-[#B9BBBE] mb-4">Current status of your Discord bot</p>
            <Skeleton className="h-6 w-24 bg-[#2F3136]" />
          </div>
          <div className="bg-[#2F3136] p-3 rounded-md text-sm">
            <div className="mb-2">
              <span className="text-[#B9BBBE]">Uptime:</span>
              <Skeleton className="h-4 w-20 bg-[#36393F] ml-2 inline-block" />
            </div>
            <div>
              <span className="text-[#B9BBBE]">Servers:</span>
              <Skeleton className="h-4 w-8 bg-[#36393F] ml-2 inline-block" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#36393F] rounded-lg shadow-lg p-5 mb-6">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-lg font-semibold text-white mb-2">Bot Status</h2>
          <p className="text-[#B9BBBE] mb-4">Current status of your Discord bot</p>
          <div className="flex items-center mt-2">
            {status?.status === 'online' ? (
              <>
                <span className="inline-block h-3 w-3 rounded-full bg-[#57F287] mr-2"></span>
                <span className="text-[#57F287] font-medium">Connected</span>
              </>
            ) : (
              <>
                <span className="inline-block h-3 w-3 rounded-full bg-[#ED4245] mr-2"></span>
                <span className="text-[#ED4245] font-medium">Disconnected</span>
              </>
            )}
          </div>
          
          {status?.status !== 'online' && (
            <div className="mt-4 p-3 bg-[#2F3136] rounded-md text-sm text-[#B9BBBE]">
              <strong className="text-[#FEE75C]">Setup Note:</strong> To enable welcome/leave messages and auto-role features, you need to enable 
              privileged intents in the Discord Developer Portal. Go to your bot's application page, 
              then to "Bot" section, and enable "SERVER MEMBERS INTENT".
            </div>
          )}
        </div>
        <div className="bg-[#2F3136] p-3 rounded-md text-sm">
          <div className="mb-2">
            <span className="text-[#B9BBBE]">Uptime:</span>
            <span className="text-white ml-2">{status?.uptime || 'Unknown'}</span>
          </div>
          <div>
            <span className="text-[#B9BBBE]">Servers:</span>
            <span className="text-white ml-2">{status?.serverCount || 0}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
