import { useState } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Config, Channel } from '../lib/botApi';
import { Zap } from 'lucide-react';

interface MessageConfigProps {
  config: Config;
  channels: Channel[];
  onConfigChange: (updates: Partial<Config>) => void;
  isUpdating: boolean;
}

export function MessageConfig({ config, channels, onConfigChange, isUpdating }: MessageConfigProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
      {/* Welcome Message Config */}
      <div className="bg-[#36393F] rounded-lg shadow-lg p-5">
        <h2 className="text-lg font-semibold text-white mb-4">Welcome Message</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-[#B9BBBE] mb-2" htmlFor="welcomeChannel">
              Channel
            </label>
            <Select 
              disabled={isUpdating} 
              value={config.welcomeChannelId || ""}
              onValueChange={(value) => onConfigChange({ welcomeChannelId: value })}
            >
              <SelectTrigger className="w-full bg-[#2F3136] border border-gray-700 rounded-md py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#5865F2]">
                <SelectValue placeholder="Select a channel" />
              </SelectTrigger>
              <SelectContent className="bg-[#2F3136] border border-gray-700 text-white">
                {channels.map((channel) => (
                  <SelectItem key={channel.id} value={channel.id} className="text-white hover:bg-[#5865F2] hover:bg-opacity-20">
                    #{channel.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#B9BBBE] mb-2" htmlFor="welcomeMessage">
              Message Template
            </label>
            <Textarea
              id="welcomeMessage"
              value={config.welcomeMessage}
              onChange={(e) => onConfigChange({ welcomeMessage: e.target.value })}
              rows={4}
              className="w-full bg-[#2F3136] border border-gray-700 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-[#5865F2]"
              disabled={isUpdating}
            />
            <p className="mt-1 text-xs text-[#B9BBBE]">
              Available variables: {'{user}'}, {'{server}'}, {'{memberCount}'}
            </p>
          </div>

          <div>
            <h3 className="block text-sm font-medium text-[#B9BBBE] mb-2">Message Preview</h3>
            <div className="p-3 bg-[#2F3136] rounded-md text-white border border-gray-700">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-[#5865F2] flex items-center justify-center">
                    <Zap className="h-6 w-6 text-white" />
                  </div>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-bold text-[#5865F2]">Welcome Bot</p>
                  <p>
                    {config.welcomeMessage
                      .replace('{user}', '@User')
                      .replace('{server}', 'Server Name')
                      .replace('{memberCount}', '100')}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Leave Message Config */}
      <div className="bg-[#36393F] rounded-lg shadow-lg p-5">
        <h2 className="text-lg font-semibold text-white mb-4">Leave Message</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-[#B9BBBE] mb-2" htmlFor="leaveChannel">
              Channel
            </label>
            <Select 
              disabled={isUpdating} 
              value={config.leaveChannelId || ""}
              onValueChange={(value) => onConfigChange({ leaveChannelId: value })}
            >
              <SelectTrigger className="w-full bg-[#2F3136] border border-gray-700 rounded-md py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#5865F2]">
                <SelectValue placeholder="Select a channel" />
              </SelectTrigger>
              <SelectContent className="bg-[#2F3136] border border-gray-700 text-white">
                {channels.map((channel) => (
                  <SelectItem key={channel.id} value={channel.id} className="text-white hover:bg-[#5865F2] hover:bg-opacity-20">
                    #{channel.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#B9BBBE] mb-2" htmlFor="leaveMessage">
              Message Template
            </label>
            <Textarea
              id="leaveMessage"
              value={config.leaveMessage}
              onChange={(e) => onConfigChange({ leaveMessage: e.target.value })}
              rows={4}
              className="w-full bg-[#2F3136] border border-gray-700 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-[#5865F2]"
              disabled={isUpdating}
            />
            <p className="mt-1 text-xs text-[#B9BBBE]">
              Available variables: {'{user}'}, {'{server}'}, {'{memberCount}'}
            </p>
          </div>

          <div>
            <h3 className="block text-sm font-medium text-[#B9BBBE] mb-2">Message Preview</h3>
            <div className="p-3 bg-[#2F3136] rounded-md text-white border border-gray-700">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-[#5865F2] flex items-center justify-center">
                    <Zap className="h-6 w-6 text-white" />
                  </div>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-bold text-[#5865F2]">Welcome Bot</p>
                  <p>
                    {config.leaveMessage
                      .replace('{user}', '@User')
                      .replace('{server}', 'Server Name')
                      .replace('{memberCount}', '99')}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
