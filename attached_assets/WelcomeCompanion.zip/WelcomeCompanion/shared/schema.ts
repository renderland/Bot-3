import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (existing)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Server schema for Discord servers
export const servers = pgTable("servers", {
  id: text("id").primaryKey(), // Discord server ID
  name: text("name").notNull(),
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
});

export const insertServerSchema = createInsertSchema(servers).pick({
  id: true,
  name: true,
});

export type InsertServer = z.infer<typeof insertServerSchema>;
export type Server = typeof servers.$inferSelect;

// Configuration schema for bot settings
export const configs = pgTable("configs", {
  id: serial("id").primaryKey(),
  serverId: text("server_id").notNull().references(() => servers.id),
  welcomeEnabled: boolean("welcome_enabled").notNull().default(true),
  leaveEnabled: boolean("leave_enabled").notNull().default(true),
  autoRoleEnabled: boolean("auto_role_enabled").notNull().default(false),
  welcomeChannelId: text("welcome_channel_id"),
  leaveChannelId: text("leave_channel_id"),
  welcomeMessage: text("welcome_message").notNull().default("Welcome {user} to the server! We're glad to have you here!"),
  leaveMessage: text("leave_message").notNull().default("{user} has left the server. We hope to see you again!"),
  autoRoleId: text("auto_role_id"),
});

export const insertConfigSchema = createInsertSchema(configs).omit({
  id: true,
});

export const updateConfigSchema = createInsertSchema(configs).omit({
  id: true,
  serverId: true,
});

export type InsertConfig = z.infer<typeof insertConfigSchema>;
export type UpdateConfig = z.infer<typeof updateConfigSchema>;
export type Config = typeof configs.$inferSelect;

// Channel schema for Discord channels
export const channels = pgTable("channels", {
  id: text("id").primaryKey(), // Discord channel ID
  serverId: text("server_id").notNull().references(() => servers.id),
  name: text("name").notNull(),
});

export const insertChannelSchema = createInsertSchema(channels);

export type InsertChannel = z.infer<typeof insertChannelSchema>;
export type Channel = typeof channels.$inferSelect;
